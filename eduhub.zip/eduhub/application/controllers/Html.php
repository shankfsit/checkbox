<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Html extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->view('html');
	}

	public function tryit_html_home(){
		$this->load->view('editors/editor_html');
	}
}
