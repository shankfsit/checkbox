<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Codeigniter extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->view('codeigniter');
	}

	public function interview_questions()
	{
		$this->load->view('codeigniter_interview_questions');
	}
}
