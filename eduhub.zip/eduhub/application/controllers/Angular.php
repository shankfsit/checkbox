<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Angular extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->view('angular2');
	}

	public function interview_questions()
	{
		$this->load->view('angular_interview_questions');
	}

	public function environmental_setup()
	{
		$this->load->view('angular_setup');
	}

	public function grunt_jasmine()
	{
		$this->load->view('angular_grunt_jasmine');
	}

	public function package_json_configuration()
	{
		$this->load->view('angular_package_json_config');
	}

	public function angular_cli()
	{
		$this->load->view('angular_cli');
	}

	public function angular_compilation()
	{
		$this->load->view('angular_compilation');
	}

	public function life_cycle_hooks()
	{
		$this->load->view('angular_life_cycle_hooks');
	}
}
