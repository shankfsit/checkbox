<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Oops extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->view('oops');
	}

	public function interview_questions()
	{
		$this->load->view('oops_interview_questions');
	}
}
