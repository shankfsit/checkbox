<!DOCTYPE html>
<html>
<head>
<title>Home || Eduhub</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>assets/layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url()?>assets/layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">
<!--[if lt IE 9]>
<link href="../layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="../layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="../layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
</head>
<body class="">
<?php include('header.php');?>
<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
    <div id="portfolio" class="three_quarter first">
      <ul class="clear">
        <h1 class="emphasise">Tutorials Available</h1>
        <li class="one_third first">
          <article class="clear">

            <figure class="post-image"><a href="<?php echo base_url()?>html"><img style="width: 1200px; height: 100px" src="<?php echo base_url()?>assets/images/demo/html1.png" alt=""></a></figure>
            <header>
              <h2 class="blog-post-title"><a href="<?php echo base_url()?>html">HTML</a></h2>
              <!-- <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div> -->
            </header>
            <p align="justify">HTML Stands for Hypertext Markup Language which is used for creating Web Pages. HTML can embed programs written in scriting languages such as Javascript , PHP etc..</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
        <li class="one_third">
          <article class="clear">
            <figure class="post-image"><a href="<?php echo base_url()?>php"><img src="<?php echo base_url()?>assets/images/demo/php.png" alt=""></a></figure>
            <header>
              <h2 class="blog-post-title"><a href="<?php echo base_url()?>php">PHP</a></h2>
              <!-- <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div> -->
            </header>
            <p align="justify">PHP is PHP Hypertext Preprocessor is a general-purpose programming language which is used for Web-Development. PHP is a server side scripting language which is used for Creating Dynamic Web Pages.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
        <li class="one_third">
          <article class="clear">
            <figure class="post-image"><img src="<?php echo base_url()?>assets/images/demo/js.png" alt=""></figure>
            <header>
              <h2 class="blog-post-title"><a href="#">Javascript</a></h2>
              <!-- <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div> -->
            </header>
            <p align="justify">Javascript is a open source client side scripting language which is used for enhancing the interaction of a user with the webpages.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
        <li class="one_third first">
          <article class="clear">
            <figure class="post-image"><img style="width: 1200px; height: 100px" src="<?php echo base_url()?>assets/images/demo/jq1.png" alt=""></figure>
            <header>
              <h2 class="blog-post-title"><a href="#">JQuery</a></h2>
              <!-- <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div> -->
            </header>
            <p align="justify">Jquery is one of the library of Javascript which is very lightweight and is used for making the use of javascript much more easier.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
        <li class="one_third">
          <article class="clear">
            <figure class="post-image"><img style="width: 1200px; height: 100px" src="<?php echo base_url()?>assets/images/demo/mysql2.png" alt=""></figure>
            <header>
              <h2 class="blog-post-title"><a href="#">Mysql</a></h2>
              <!-- <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div> -->
            </header>
            <p align="justify">Mysql is a open source relational database management System Which is used to store and manipulate data.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
        <li class="one_third">
          <article class="clear">
            <figure class="post-image"><img style="width: 1200px; height: 100px" src="<?php echo base_url()?>assets/images/demo/css.png" alt=""></figure>
            <header>
              <h2 class="blog-post-title"><a href="#">CSS</a></h2>
              <!-- <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div> -->
            </header>
            <p align="justify">CSS Stands for Cascading Style Sheet is a style sheet language which describes the style of the HTML Document. </p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
        <!-- <li class="one_third first">
          <article class="clear">
            <figure class="post-image"><img src="<?php echo base_url()?>assets/images/demo/1200x400.gif" alt=""></figure>
            <header>
              <h2 class="blog-post-title"><a href="#">Pellentesque Tempor Tellus</a></h2>
              <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div>
            </header>
            <p>Portortornec condimenterdum eget consectetuer condis consequam pretium pellus sed mauris enim. Puruselit mauris nulla hendimentesque elit semper nam a sapien urna sempus. Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
        <li class="one_third">
          <article class="clear">
            <figure class="post-image"><img src="<?php echo base_url()?>assets/images/demo/1200x400.gif" alt=""></figure>
            <header>
              <h2 class="blog-post-title"><a href="#">Pellentesque Tempor Tellus</a></h2>
              <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div>
            </header>
            <p>Portortornec condimenterdum eget consectetuer condis consequam pretium pellus sed mauris enim. Puruselit mauris nulla hendimentesque elit semper nam a sapien urna sempus. Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
        <li class="one_third">
          <article class="clear">
            <figure class="post-image"><img src="<?php echo base_url()?>assets/images/demo/1200x400.gif" alt=""></figure>
            <header>
              <h2 class="blog-post-title"><a href="#">Pellentesque Tempor Tellus</a></h2>
              <div class="blog-post-meta">
                <ul>
                  <li class="blog-post-date">
                    <time datetime="2000-04-06T08:15+00:00"><strong>Completed:</strong> 6<sup>th</sup> April 2000</time>
                  </li>
                  <li class="blog-post-cats"><a href="#">Category 1</a>, <a href="#">Category 2</a></li>
                </ul>
              </div>
            </header>
            <p>Portortornec condimenterdum eget consectetuer condis consequam pretium pellus sed mauris enim. Puruselit mauris nulla hendimentesque elit semper nam a sapien urna sempus. Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </li>
      </ul>-->
      <!-- ####################################################################################################### -->
      <!-- <nav class="pagination">
        <ul>
          <li class="prev"><a href="#">&laquo; Previous</a></li>
          <li><a href="#">1</a></li>
          <li><a href="#">2</a></li>
          <li class="splitter"><strong>&hellip;</strong></li>
          <li><a href="#">6</a></li>
          <li class="current"><strong>7</strong></li>
          <li><a href="#">8</a></li>
          <li class="splitter"><strong>&hellip;</strong></li>
          <li><a href="#">14</a></li>
          <li><a href="#">15</a></li>
          <li class="next"><a href="#">Next &raquo;</a></li>
        </ul>
      </nav> -->
    </div> 
    <!-- ################################################################################################ -->
    <div id="sidebar_1" class="sidebar one_quarter">
      <aside class="clear">
        <!-- ########################################################################################## -->
        <h2>Aliquatjusto Nam</h2>
        <section class="clear">
          <ul class="nospace">
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
          </ul>
        </section>
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<!-- Footer -->
<?php include('footer.php')?>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/layout/scripts/jquery-latest.min.js"><\/script>\
<script src="<?php echo base_url()?>assets/layout/scripts/jquery-ui.min.js"><\/script>')</script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); });</script>
<script src="<?php echo base_url()?>assets/layout/scripts/jquery-mobilemenu.min.js"></script>
<script src="<?php echo base_url()?>assets/layout/scripts/custom.js"></script>
</body>
</html>