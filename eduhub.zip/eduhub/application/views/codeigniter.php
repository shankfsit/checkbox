<!DOCTYPE html>
<html>
<head>
<title>Eduhub - OOPS</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>assets/layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url()?>assets/layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">
<!--[if lt IE 9]>
<link href="../layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="../layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="../layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
</head>
<body class="">
<?php include('header.php');?>
<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
    <?php include('sidebars/sidebar_oops.php');?>
    <!-- ################################################################################################ -->
    <div class="one_half">
      <section class="clear">
        <h1>OOPS Tutorials</h1>
        <figure class="imgr boxholder"><img style="width: 120px;height: 120px;" src="<?php echo base_url()?>assets/images/demo/php2.jpg" alt=""></figure>
        <p align="justify">The PHP Hypertext Preprocessor (PHP) is a programming language that allows web developers to create dynamic content that interacts with databases. PHP is basically used for developing web based software applications. This tutorial helps you to build your base with PHP.</p>
        <div class="divider2"></div>
        <h4>Why to Learn PHP?</h4>
        <p align="justify">PHP started out as a small open source project that evolved as more and more people found out how useful it was. Rasmus Lerdorf unleashed the first version of PHP way back in 1994.</p>
        <p align="justify">PHP is a MUST for students and working professionals to become a great Software Engineer specially when they are working in Web Development Domain. I will list down some of the key advantages of learning PHP:</p>
        <ul>
          <li>PHP is a recursive acronym for "PHP: Hypertext Preprocessor".</li>
          <li>PHP is a server side scripting language that is embedded in HTML. It is used to manage dynamic content, databases, session tracking, even build entire e-commerce sites.</li>
          <li>It is integrated with a number of popular databases, including MySQL, PostgreSQL, Oracle, Sybase, Informix, and Microsoft SQL Server.</li>
          <li>PHP is pleasingly zippy in its execution, especially when compiled as an Apache module on the Unix side. The MySQL server, once started, executes even very complex queries with huge result sets in record-setting time.</li>
          <li>PHP supports a large number of major protocols such as POP3, IMAP, and LDAP. PHP4 added support for Java and distributed object architectures (COM and CORBA), making n-tier development a possibility for the first time.</li>
          <li>PHP is forgiving: PHP language tries to be as forgiving as possible.</li>
          <li>PHP Syntax is C-Like.</li>
        </ul>
        <div class="divider2"></div>
        <h4>Characteristics of PHP</h4>
        <p>Five important characteristics make PHP's practical nature possible −</p>
        <ul>
          <li>Simplicity</li>
          <li>Efficiency</li>
          <li>Security</li>
          <li>Flexibility</li>
          <li>Familiarity</li>
        </ul>
        <div class="divider2"></div>
        <h4>Hello World using PHP.</h4>
        <p>Just to give you a little excitement about PHP, I'm going to give you a small conventional PHP Hello World program, You can try it using Demo link.</p>
        <section>
        <h2>Lets Start With an Example</h2>

        <div class="calltoaction opt1">
          <div class="push20">
            <xmp style="text-transform: lowercase;margin-left: -125px;margin-top: -40px;">
              <!DOCTYPE html>
              <html>
              <head>
                <title>This is My Fisrt HTML Exercise</title>
              </head>
              <body>
                <?php echo "Hello, World!";?>
              </body>
              </html>
            </xmp> 
          </div>
        </div>
        
      </section>
      <div class="divider2"></div>
      <h4>Applications of PHP</h4>
        <p align="justify">As mentioned before, PHP is one of the most widely used language over the web. I'm going to list few of them here:</p>
        <ul>
          <li>PHP performs system functions, i.e. from files on a system it can create, open, read, write, and close them.</li>
          <li>PHP can handle forms, i.e. gather data from files, save data to a file, through email you can send data, return data to the user.</li>
          <li>You add, delete, modify elements within your database through PHP.</li>
          <li>Access cookies variables and set cookies.</li>
          <li>Using PHP, you can restrict users to access some pages of your website.</li>
          <li>It can encrypt data.</li>
        </ul>
        <div class="divider2"></div>
        <h4>Prerequisites</h4>
        <p align="justify">Before proceeding with this tutorial you should have at least basic understanding of computer programming, Internet, Database, and MySQL etc is very helpful.</p>
      </section>
    </div>
    <!-- ################################################################################################ -->
    <div id="sidebar_2" class="sidebar one_quarter">
      <aside class="clear">
        <!-- ########################################################################################## -->
        
        <section class="clear">
          <ul class="nospace">
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
          </ul>
        </section>
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<!-- Footer -->
<?php include('footer.php')?>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>window.jQuery || document.write('<script src="../layout/scripts/jquery-latest.min.js"><\/script>\
<script src="../layout/scripts/jquery-ui.min.js"><\/script>')</script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); });</script>
<script src="../layout/scripts/jquery-mobilemenu.min.js"></script>
<script src="../layout/scripts/custom.js"></script>
</body>
</html>