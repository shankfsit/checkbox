<!DOCTYPE html>
<html>
<head>
<title>Eduhub - OOPS Interview Questions</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>assets/layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url()?>assets/layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">
<!--[if lt IE 9]>
<link href="../layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="../layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="../layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
</head>
<body class="">
<?php include('header.php');?>
<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
    <?php include('sidebars/sidebar_interview_questions.php');?>
    <!-- ################################################################################################ -->
    <div class="one_half">
      <section class="clear">
        <h1>OOPS Interview Questions</h1>
        <figure class="imgr boxholder"><img style="width: 120px;height: 120px;" src="<?php echo base_url()?>assets/images/demo/php2.jpg" alt=""></figure>
        <p><b>1) What is OOPS ?</b></p>
        <p align="justify">OOPS is stated as Object Orientated Programming System in which the program is based on objects. Object is nothing but an instance of a class which is consists of a properties and methods. </p>
        <hr>
        <a href="#"><img src="<?php echo base_url()?>assets/images/demo/hor_ads1.jpg" alt=""></a>
        <p><b>2) What are the different features of OOPS ?</b></p>
        <p align="justify">Following are the Features of OOPS :-
         <ul>
           <li>Abstraction</li>
           <li>Encapsulation</li>
           <li>Inheritance</li>
           <li>Polymerphism</li>
         </ul> 
        </p>
        <hr>
        <p><b>3) What is a Class ?</b></p>
        <p align="justify">A Class is a combination of properties and methods and a class can be represented by creating the instances</p>
        <hr>
        <p><b>4) What is an Objects ?</b></p>
        <p align="justify">An Object is a instance of a Class which is having its own state, behaviour and Identity.</p>
        <hr>
        <p><b>5) What is Abstraction ?</b></p>
        <p align="justify">Abstraction is one of the core features of Object Oriented Programming System. Abstraction is a concept of hiding the internal details of the Application and displaying only the essential informations to the users in a simplest way. Access Modifiers plays an important role in order to get the concept of abstraction.</p>
        <hr>
        <p><b>6) What is Encapsulation ?</b></p>
        <p align="justify">Encapsulation is one of the fundamental concept of Object Oriented Programming System. Encapsulation is a concept of Wrapping or bundling of the data and the function/methods into a single unit and then manipulate them according to the requirements.<br>
          e.g : Class is an example of encapsulation. A class bundled all the properties and functions in a single unit.
        </p>
        <hr>
        <p><b>7) What is Inheritance and what are the Types ?</b></p>
        <p align="justify">Inheritance is one of the important feature of Object Oriented Programming System. Inheritance is a mechanism in which one class acquires the properties and methods of the another class by using a keyword 'extends', Following are the types of Inheritance:
          <ul>
            <li>Single Inheritance</li>
            <li>Multiple Inheritance</li>
            <li>Multilevel Inheritance</li>
            <li>Hierarchical Inheritance</li>
            <li>Hybrid Inheritance</li>
          </ul>
        </p>
        <hr>
        <p><b>8) What is Polymorphism ?</b></p>
        <p align="justify">Polymorphism is one of the main concept in Object Oriented Programming System. Polymorphism means has many forms. Polymorphism is a concept where different classes that are related to each other by inheritance uses those methods to perform a different task. Function Overloading and Function Overriding are the examples of Polymorphism.
        </p>
        <hr>
        <p><b>9) What is Function Overloading ?</b></p>
        <p align="justify"> Function Overloading means when there are multiple function having same name but having different parameters then these functions are called as function Overloading. Function Overloading can be achieved by changing the number of arguments or by changing the type of argument. PHP doesn't Support Function Overloading but we can overload a method by using magic method __call.
        </p>
        <hr>
        <p><b>10) What is Function Overriding ?</b></p>
        <p align="justify"> Function Overriding can be confined to derived class. When the parent class has a method defined and the child class override the method then this is called as Function Overriding.
        </p>
        <hr>
        
        
      </section>
      <section>
        <h1>Other Interview Questions</h1>
        <table>
          <tbody>
            <tr class="light">
              <td><a style="color: black;" href="<?php echo base_url()?>javascript/interview_questions">Javascript Interview Questions</a></td>
              <td><a style="color: black;" href="<?php echo base_url()?>jquery/interview_questions">Jquery Interview Questions</a></td>
              
            </tr>
            <tr class="dark">
              <td><a style="color: black;" href="<?php echo base_url()?>mysql/interview_questions">Mysql Interview Questions</a></td>
              <td><a style="color: black;" href="<?php echo base_url()?>oops/interview_questions">OOPS Interview Questions</a></td>
            </tr>
          </tbody>
        </table>
      </section>
    </div>
    <!-- ################################################################################################ -->
    <div id="sidebar_2" class="sidebar one_quarter">
      <aside class="clear">
        <!-- ########################################################################################## -->
        
        <section class="clear">
          <ul class="nospace">
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/vertical_ads1.jpg" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/vertical_ads2.gif" alt=""></a></li>
          </ul>
        </section>
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<!-- Footer -->
<?php include('footer.php')?>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>window.jQuery || document.write('<script src="../layout/scripts/jquery-latest.min.js"><\/script>\
<script src="../layout/scripts/jquery-ui.min.js"><\/script>')</script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); });</script>
<script src="../layout/scripts/jquery-mobilemenu.min.js"></script>
<script src="../layout/scripts/custom.js"></script>
</body>
</html>