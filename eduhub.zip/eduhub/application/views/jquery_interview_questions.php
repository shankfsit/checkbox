<!DOCTYPE html>
<html>
<head>
<title>Eduhub - Jquery Interview Questions</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>assets/layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url()?>assets/layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">
<!--[if lt IE 9]>
<link href="../layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="../layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="../layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
</head>
<body class="">
<?php include('header.php');?>
<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
    <?php include('sidebars/sidebar_jquery.php');?>
    <!-- ################################################################################################ -->
    <div class="one_half">
      <section class="clear">
        <h1>Jquery Interview Questions</h1>
        <figure class="imgr boxholder"><img style="width: 120px;height: 120px;" src="<?php echo base_url()?>assets/images/demo/php2.jpg" alt=""></figure>
        <p><b>1) What is Jquery?</b></p>
        <p align="justify">The PHP Hypertext Preprocessor (PHP) is a programming language that allows web developers to create dynamic content that interacts with databases. PHP is basically used for developing web based software applications. This tutorial helps you to build your base with PHP.</p>
        <hr>
        <p><b>2) What is $_GET Method ?</b></p>
        <p align="justify">GET Method have some limit like only 2kb data able to send for request.</p>
        <hr>
        <p><b>3) What is $_POST Method ?</b></p>
        <p align="justify">$_POST Method is used to send the data through http. The data send from post method is very secure as compared to GET Method.</p>
        <hr>
        <p><b>4) In how many ways we can retreive the data in the result set of Mysql using php ?</b></p>
        <p align="justify">We can retreive the data in 4 ways :-
         <ul>
           <li>mysql_fetch_row</li>
           <li>mysql_fetch_array</li>
           <li>mysql_fetch_object</li>
           <li>mysql_fetch_assoc</li>
         </ul> 
        </p>
        <hr>
        <p><b>5) What is PEAR in PHP ?</b></p>
        <p align="justify">PEAR Stands for PHP Extension and Application Repository. PEAR is a framework and a repository for reusable PHP Components.</p>
        <hr>
        <p><b>6) What is the latest version of PHP ?</b></p>
        <p align="justify">The latest version of PHP is 7.3 Which was released on 6th December 2018.</p>
        <hr>
        <p><b>7) What is the difference between PHP4 and PHP5 ?</b></p>
        <p align="justify">PHP4 doesn't support OOPS Concept.<br> PHP5 Supports OOPS Concepts.</p>
        <hr>
        <p><b>8) What is the Difference between "echo" and "print" in PHP ?</b></p>
        <p align="justify">Echo can give the output for one or more strings whereas print can give output for only one string. <br>
          Echo is faster than print as echo doesn't return any value whereas print always return 1.
        </p>
        <hr>
        <p><b>9) What is data type and how many data types available in PHP ?</b></p>
        <p align="justify"> Data get stored in Variables with different types. Following are the data types available in PHP:
          <ul>
            <li>String</li>
            <li>Integer</li>
            <li>Float</li>
            <li>Array</li>
            <li>Boolean</li>
            <li>Object</li>
            <li>NULL</li>
            <li>Reference</li>
          </ul>
        </p>
        <hr>
        <p><b>10) What is Cookies ?</b></p>
        <p align="justify">A Cookie is used to identify a user. cookie is a small file which the server embed into the user's computer. Each time the computer open the page with the browser, it will send the cookie too. Creating cookie in PHP:<br>
          setcookie(name, value, expire, path, domain, secure, httponly)
        </p>
        <hr>
        
        
      </section>
    </div>
    <!-- ################################################################################################ -->
    <div id="sidebar_2" class="sidebar one_quarter">
      <aside class="clear">
        <!-- ########################################################################################## -->
        
        <section class="clear">
          <ul class="nospace">
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
          </ul>
        </section>
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<!-- Footer -->
<?php include('footer.php')?>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>window.jQuery || document.write('<script src="../layout/scripts/jquery-latest.min.js"><\/script>\
<script src="../layout/scripts/jquery-ui.min.js"><\/script>')</script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); });</script>
<script src="../layout/scripts/jquery-mobilemenu.min.js"></script>
<script src="../layout/scripts/custom.js"></script>
</body>
</html>