<!DOCTYPE html>
<html>
<head>
<title>Home || Eduhub</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>assets/layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url()?>assets/layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">
<!--[if lt IE 9]>
<link href="layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
</head>
<body class="">

<?php include('header.php');?>
<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
    <div id="homepage" class="clear">
      <div class="three_quarter first">
        <article class="clear">
          <h1 class="emphasise">Main Article Headline</h1>
          <div class="one_third first"><img src="<?php echo base_url()?>assets/images/demo/570x570.gif" alt=""></div>
          <div class="two_third">
            <p class="nospace">Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.</p>
            <p>Donec a erat in enim cursus gravida id non urna. Vivamus feugiat mauris sed sem tristique non eleifend lorem elementum. Integer imperdiet vestibulum leo ut tincidunt. In sagittis diam ut leo convallis vel rutrum mauris ullamcorper. Vestibulum adipiscing erat sit amet justo luctus molestie. In hac habitasse platea dictumst.</p>
            <p>In lacinia erat id ante faucibus tristique. Integer egestas elementum risus vel rutrum. Mauris vel augue sit amet lectus hendrerit auctor non nec purus.</p>
            <footer><a href="#" class="button medium gradient orange rnd5">Read More &raquo;</a></footer>
          </div>
        </article>
        <div class="divider2"></div>
        <div class="one_half first">
          <ul class="nospace spacing">
            <li>
              <figure class="clear">
                <div class="imgl boxholder"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></div>
                <figcaption>Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.
                  <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
                </figcaption>
              </figure>
            </li>
            <li>
              <figure class="clear">
                <div class="imgl boxholder"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></div>
                <figcaption>Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.
                  <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
                </figcaption>
              </figure>
            </li>
            <li>
              <figure class="clear">
                <div class="imgl boxholder"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></div>
                <figcaption>Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.
                  <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
                </figcaption>
              </figure>
            </li>
          </ul>
          <div class="divider2"></div>
          <article class="one_half first">
            <div class="push20"><img src="<?php echo base_url()?>assets/images/demo/1200x400.gif" alt=""></div>
            <h2 class="font-medium nospace">Article Headline</h2>
            <p>Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
          <article class="one_half">
            <div class="push20"><img src="<?php echo base_url()?>assets/images/demo/1200x400.gif" alt=""></div>
            <h2 class="font-medium nospace">Article Headline</h2>
            <p>Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
          <div class="clear"></div>
        </div>
        <!-- #### -->
        <!-- #### -->
        <!-- #### -->
        <div class="one_half">
          <article class="push30">
            <div class="push20"><img src="<?php echo base_url()?>assets/images/demo/1200x400.gif" alt=""></div>
            <h2 class="nospace">Article Headline</h2>
            <p>Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.</p>
            <p>Donec a erat in enim cursus gravida id non urna. Vivamus feugiat mauris sed sem tristique non eleifend lorem elementum. Integer imperdiet vestibulum leo ut tincidunt.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
          <article>
            <div class="push20"><img src="<?php echo base_url()?>assets/images/demo/1200x400.gif" alt=""></div>
            <h2 class="nospace">Article Headline</h2>
            <p>Aliquatjusto quisque nam consequat doloreet vest orna partur scetur portortis nam. Metadipiscing eget facilis elit sagittis felisi eger id justo maurisus convallicitur.</p>
            <p>Donec a erat in enim cursus gravida id non urna. Vivamus feugiat mauris sed sem tristique non eleifend lorem elementum. Integer imperdiet vestibulum leo ut tincidunt.</p>
            <footer class="read-more"><a href="#">Read More &raquo;</a></footer>
          </article>
        </div>
        <div class="clear"></div>
      </div>
      <!-- #### -->
      <!-- #### -->
      <!-- #### -->
      <!-- #### -->
      <div class="one_quarter">
        <article class="push30">
          <div class="push20"><img src="<?php echo base_url()?>assets/images/demo/1200x400.gif" alt=""></div>
          <h2 class="font-medium nospace"><a href="#">Headline Text</a></h2>
          <p>Donec a erat in enim cursus gravida id non urna. Vivamus feugiat mauris sed sem tristique non eleifend lorem.</p>
        </article>
        <div class="boxholder rnd8 push30">
          <h2 class="font-medium nospace">Headline Text</h2>
          <ul class="list none">
            <li><a href="#">Etiam id sapien vitae neque.</a></li>
            <li><a href="#">Maecenas cursus lectus purus.</a></li>
            <li><a href="#">Etiam fermentum nulla enim.</a></li>
            <li><a href="#">Sed aliquet semper eros.</a></li>
            <li><a href="#">Nullam tempus dictum neque.</a></li>
            <li><a href="#">Cras ut sapien ut augue.</a></li>
          </ul>
        </div>
        <article>
          <div class="push20"><img src="<?php echo base_url()?>assets/images/demo/video.gif" alt=""></div>
          <h2 class="font-medium nospace"><a href="#">Headline Text</a></h2>
          <p>Donec a erat in enim cursus gravida id non urna. Vivamus feugiat mauris sed sem tristique non eleifend lorem.</p>
        </article>
        <div class="divider2"></div>
        <div class="tab-wrapper rnd8 clear">
          <ul class="tab-nav clear">
            <li><a href="#tab-1">Title 1</a></li>
            <li><a href="#tab-2">Title 2</a></li>
          </ul>
          <div class="tab-container">
            <!-- Tab Content -->
            <div id="tab-1" class="tab-content clear">
              <ul class="list arrow">
                <li><a href="#">Donec vestibulum est eget</a></li>
                <li><a href="#">Vestibulum at nulla eu est</a></li>
                <li><a href="#">Ut in est orci, scelerisque</a></li>
                <li><a href="#">Proin tempor luctus arcu</a></li>
                <li><a href="#">Nullam dictum erat vel</a></li>
                <li><a href="#">Donec condimentum dui</a></li>
              </ul>
            </div>
            <!-- ## TAB 2 ## -->
            <div id="tab-2" class="tab-content clear">
              <ul class="list tick">
                <li><a href="#">Donec vestibulum est eget</a></li>
                <li><a href="#">Vestibulum at nulla eu est</a></li>
                <li><a href="#">Ut in est orci, scelerisque</a></li>
                <li><a href="#">Proin tempor luctus arcu</a></li>
                <li><a href="#">Nullam dictum erat vel</a></li>
                <li><a href="#">Donec condimentum dui</a></li>
              </ul>
            </div>
            <!-- / Tab Content -->
          </div>
        </div>
      </div>
    </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<!-- Footer -->
<div class="wrapper row2">
  <div id="footer" class="clear">
    <div class="one_quarter first">
      <h2 class="footer_title">Footer Navigation</h2>
      <nav class="footer_nav">
        <ul class="nospace">
          <li><a href="#">Home Page</a></li>
          <li><a href="#">Our Services</a></li>
          <li><a href="#">Meet the Team</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#">Contact Us</a></li>
          <li><a href="#">Gallery</a></li>
          <li><a href="#">Portfolio</a></li>
          <li><a href="#">Online Shop</a></li>
        </ul>
      </nav>
    </div>
    <div class="one_quarter">
      <h2 class="footer_title">Latest Gallery</h2>
      <ul id="ft_gallery" class="nospace spacing clear">
        <li class="one_third first"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
        <li class="one_third"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
        <li class="one_third"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
        <li class="one_third first"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
        <li class="one_third"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
        <li class="one_third"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
        <li class="one_third first"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
        <li class="one_third"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
        <li class="one_third"><a href="#"><img src="<?php echo base_url()?>assets/images/demo/80x80.gif" alt=""></a></li>
      </ul>
    </div>
    <div class="one_quarter">
      <h2 class="footer_title">From Twitter</h2>
      <div class="tweet-container">
        <ul class="list none">
          <li><strong>@<a href="#">name</a></strong> <span class="tweet_text">RT <span class="at">@</span><a href="#">name</a> Donec suscipit vehicula turpis sed lutpat Quisque vitae quam neque.</span> <span class="tweet_time"><a href="#">about 9 hours ago</a></span></li>
          <li><strong>@<a href="#">name</a></strong> <span class="tweet_text">RT <span class="at">@</span><a href="#">name</a> Donec suscipit vehicula turpis sed lutpat Quisque vitae quam neque.</span> <span class="tweet_time"><a href="#">about 9 hours ago</a></span></li>
          <li><strong>@<a href="#">name</a></strong> <span class="tweet_text">RT <span class="at">@</span><a href="#">name</a> Donec suscipit vehicula turpis sed lutpat Quisque vitae quam neque.</span> <span class="tweet_time"><a href="#">about 9 hours ago</a></span></li>
          <li><strong>@<a href="#">name</a></strong> <span class="tweet_text">RT <span class="at">@</span><a href="#">name</a> Donec suscipit vehicula turpis sed lutpat Quisque vitae quam neque.</span> <span class="tweet_time"><a href="#">about 9 hours ago</a></span></li>
        </ul>
      </div>
    </div>
    <div class="one_quarter">
      <h2 class="footer_title">Contact Us</h2>
      <form class="rnd5" action="#" method="post">
        <div class="form-input clear">
          <label for="ft_author">Name <span class="required">*</span><br>
            <input type="text" name="ft_author" id="ft_author" value="" size="22">
          </label>
          <label for="ft_email">Email <span class="required">*</span><br>
            <input type="text" name="ft_email" id="ft_email" value="" size="22">
          </label>
        </div>
        <div class="form-message">
          <textarea name="ft_message" id="ft_message" cols="25" rows="10"></textarea>
        </div>
        <p>
          <input type="submit" value="Submit" class="button small orange">
          &nbsp;
          <input type="reset" value="Reset" class="button small grey">
        </p>
      </form>
    </div>
  </div>
</div>
<div class="wrapper row4">
  <div id="copyright" class="clear">
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="#">Domain Name</a></p>
    <p class="fl_right">Template by <a target="_blank" href="https://www.os-templates.com/" title="Free Website Templates">OS Templates</a></p>
  </div>
</div>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/layout/scripts/jquery-latest.min.js"><\/script>\
<script src="<?php echo base_url()?>assets/layout/scripts/jquery-ui.min.js"><\/script>')</script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); });</script>
<script src="<?php echo base_url()?>assets/layout/scripts/jquery-mobilemenu.min.js"></script>
<script src="<?php echo base_url()?>assets/layout/scripts/custom.js"></script>
</body>
</html>