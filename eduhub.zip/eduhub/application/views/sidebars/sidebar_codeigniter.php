<div id="sidebar_1" class="sidebar one_quarter first">
      <aside>
        <!-- ########################################################################################## -->
        <h2>Codeigniter Tutorials</h2>
        <nav>
          <ul>
            <li><a href="#">Codeigniter Home</a></li>
            <li><a href="#">Codeigniter Introduction</a></li>
            <li><a href="#">Codeigniter Setup</a>
              <!-- <ul>
                <li><a href="#">Free HTML 5 Templates</a></li>
                <li><a href="#">Free Webdesign Templates</a>
                  <ul>
                    <li><a href="#">Free FireWorks Templates</a></li>
                    <li><a href="#">Free PNG Templates</a></li>
                  </ul>
                </li>
              </ul> -->
            </li>
            <li><a href="#">Codeigniter Syntax</a></li>
            <li><a href="#">Codeigniter Variables</a></li>
            <li><a href="#">Codeigniter Constants</a></li>
            <li><a href="#">Codeigniter echo/print</a></li>
            <li><a href="#">Codeigniter Data Types</a></li>
            <li><a href="#">Codeigniter LCodeigniter</a></li>
            <li><a href="#">Codeigniter Strings</a></li>
            <li><a href="#">Codeigniter Arrays</a></li>
            <li><a href="#">Codeigniter Functions</a></li>
            <li><a href="#">Codeigniter Operators</a></li>
            <li><a href="#">Codeigniter Cookies</a></li>
            <li><a href="#">Codeigniter Session</a></li>
            <li><a href="#">Codeigniter Superglobals</a></li>
          </ul>
        </nav>
        <h2>Codeigniter Forms</h2>
        <nav>
          <ul>
            <li><a href="#">Codeigniter Form Handling</a></li>
            <li><a href="#">Codeigniter Form Validations</a></li>
            <li><a href="#">Codeigniter Form Complete</a></li>
          </ul>
        </nav>
        <h2>Codeigniter Advanced</h2>
        <nav>
          <ul>
            <li><a href="#">Codeigniter Math Function</a></li>
            <li><a href="#">Codeigniter Date & Time</a></li>
            <li><a href="#">Codeigniter File Handling</a></li>
            <li><a href="#">Codeigniter File Uploads</a></li>
            <li><a href="#">Codeigniter File Jsons</a></li>
          </ul>
        </nav>
        <h2>Codeigniter Codeigniter</h2>
        <nav>
          <ul>
            <li><a href="#">Codeigniter Codeigniter Intro</a></li>
            <li><a href="#">Codeigniter Classes & Objects</a></li>
            <li><a href="#">Codeigniter Constructor</a></li>
            <li><a href="#">Codeigniter Destructor</a></li>
            <li><a href="#">Codeigniter Access Modifiers</a></li>
            <li><a href="#">Codeigniter Inheritance</a></li>
            <li><a href="#">Codeigniter Constants</a></li>
            <li><a href="#">Codeigniter Abstract Classes</a></li>
            <li><a href="#">Codeigniter Traits</a></li>
            <li><a href="#">Codeigniter Static Classes</a></li>
            <li><a href="#">Codeigniter Static Methods & Properties</a></li>
          </ul>
        </nav>
        <!-- /nav -->
        <!-- <section>
          <h2>Get In Contact</h2>
          <address>
          Full Name<br>
          Address Line 1<br>
          Address Line 2<br>
          Town/City<br>
          Postcode/Zip<br>
          <br>
          Tel: xxxx xxxx xxxxxx<br>
          Email: <a href="#">contact@domain.com</a>
          </address>
        </section> -->
        <!-- /section -->
        <!-- <section>
          <article>
            <h2>Lorem ipsum dolor</h2>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed.</p>
            <ul class="list indent disc">
              <li><a href="#">Lorem ipsum dolor sit</a></li>
              <li>Etiam vel sapien et</li>
              <li><a href="#">Etiam vel sapien et</a></li>
            </ul>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed. Condimentumsantincidunt dui mattis magna intesque purus orci augue lor nibh.</p>
            <p class="more"><a href="#">Continue Reading &raquo;</a></p>
          </article>
        </section> -->
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>