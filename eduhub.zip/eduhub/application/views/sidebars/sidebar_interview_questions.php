<div id="sidebar_1" class="sidebar one_quarter first">
      <aside>
        <!-- ########################################################################################## -->
        <h2>Technical Interview Questions</h2>
        <nav>
          <ul>
            <li><a href="<?php echo base_url()?>php/interview_questions">PHP Interview Questions</a></li>
            <li><a href="<?php echo base_url()?>javascript/interview_questions">Javascript Interview Questions</a></li>
            <li><a href="<?php echo base_url()?>jquery/interview_questions">Jquery Interview Questions</a></li>
            <li><a href="<?php echo base_url()?>mysql/interview_questions">Mysql Interview Questions</a></li>
            <li><a href="<?php echo base_url()?>oops/interview_questions">OOPS Interview Questions</a></li>
            <li><a href="<?php echo base_url()?>c/interview_questions">C Interview Questions</a></li>
            <li><a href="<?php echo base_url()?>angular/interview_questions">Angular Interview Questions</a></li>
            <li><a href="<?php echo base_url()?>codeigniter/interview_questions">Codeigniter Interview Questions</a></li>
          </ul>
        </nav>
        <h2>Non Technical Interview Questions</h2>
        <nav>
          <ul>
            <li><a href="#">HR Common Interview Questions</a></li>
            
          </ul>
        </nav>
        
        <!-- /nav -->
        <!-- <section>
          <h2>Get In Contact</h2>
          <address>
          Full Name<br>
          Address Line 1<br>
          Address Line 2<br>
          Town/City<br>
          Postcode/Zip<br>
          <br>
          Tel: xxxx xxxx xxxxxx<br>
          Email: <a href="#">contact@domain.com</a>
          </address>
        </section> -->
        <!-- /section -->
        <!-- <section>
          <article>
            <h2>Lorem ipsum dolor</h2>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed.</p>
            <ul class="list indent disc">
              <li><a href="#">Lorem ipsum dolor sit</a></li>
              <li>Etiam vel sapien et</li>
              <li><a href="#">Etiam vel sapien et</a></li>
            </ul>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed. Condimentumsantincidunt dui mattis magna intesque purus orci augue lor nibh.</p>
            <p class="more"><a href="#">Continue Reading &raquo;</a></p>
          </article>
        </section> -->
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>