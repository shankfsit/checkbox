<div id="sidebar_1" class="sidebar one_quarter first">
      <aside>
        <!-- ########################################################################################## -->
        <h2>PHP Tutorials</h2>
        <nav>
          <ul>
            <li><a href="#">PHP Home</a></li>
            <li><a href="#">PHP Introduction</a></li>
            <li><a href="#">PHP Setup</a>
              <!-- <ul>
                <li><a href="#">Free HTML 5 Templates</a></li>
                <li><a href="#">Free Webdesign Templates</a>
                  <ul>
                    <li><a href="#">Free FireWorks Templates</a></li>
                    <li><a href="#">Free PNG Templates</a></li>
                  </ul>
                </li>
              </ul> -->
            </li>
            <li><a href="#">PHP Syntax</a></li>
            <li><a href="#">PHP Variables</a></li>
            <li><a href="#">PHP Constants</a></li>
            <li><a href="#">PHP echo/print</a></li>
            <li><a href="#">PHP Data Types</a></li>
            <li><a href="#">PHP Loops</a></li>
            <li><a href="#">PHP Strings</a></li>
            <li><a href="#">PHP Arrays</a></li>
            <li><a href="#">PHP Functions</a></li>
            <li><a href="#">PHP Operators</a></li>
            <li><a href="#">PHP Cookies</a></li>
            <li><a href="#">PHP Session</a></li>
            <li><a href="#">PHP Superglobals</a></li>
          </ul>
        </nav>
        <h2>PHP Forms</h2>
        <nav>
          <ul>
            <li><a href="#">PHP Form Handling</a></li>
            <li><a href="#">PHP Form Validations</a></li>
            <li><a href="#">PHP Form Complete</a></li>
          </ul>
        </nav>
        <h2>PHP Advanced</h2>
        <nav>
          <ul>
            <li><a href="#">PHP Math Function</a></li>
            <li><a href="#">PHP Date & Time</a></li>
            <li><a href="#">PHP File Handling</a></li>
            <li><a href="#">PHP File Uploads</a></li>
            <li><a href="#">PHP File Jsons</a></li>
          </ul>
        </nav>
        <h2>PHP OOPS</h2>
        <nav>
          <ul>
            <li><a href="#">PHP OOPS Intro</a></li>
            <li><a href="#">PHP Classes & Objects</a></li>
            <li><a href="#">PHP Constructor</a></li>
            <li><a href="#">PHP Destructor</a></li>
            <li><a href="#">PHP Access Modifiers</a></li>
            <li><a href="#">PHP Inheritance</a></li>
            <li><a href="#">PHP Constants</a></li>
            <li><a href="#">PHP Abstract Classes</a></li>
            <li><a href="#">PHP Traits</a></li>
            <li><a href="#">PHP Static Classes</a></li>
            <li><a href="#">PHP Static Methods & Properties</a></li>
          </ul>
        </nav>
        <!-- /nav -->
        <!-- <section>
          <h2>Get In Contact</h2>
          <address>
          Full Name<br>
          Address Line 1<br>
          Address Line 2<br>
          Town/City<br>
          Postcode/Zip<br>
          <br>
          Tel: xxxx xxxx xxxxxx<br>
          Email: <a href="#">contact@domain.com</a>
          </address>
        </section> -->
        <!-- /section -->
        <!-- <section>
          <article>
            <h2>Lorem ipsum dolor</h2>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed.</p>
            <ul class="list indent disc">
              <li><a href="#">Lorem ipsum dolor sit</a></li>
              <li>Etiam vel sapien et</li>
              <li><a href="#">Etiam vel sapien et</a></li>
            </ul>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed. Condimentumsantincidunt dui mattis magna intesque purus orci augue lor nibh.</p>
            <p class="more"><a href="#">Continue Reading &raquo;</a></p>
          </article>
        </section> -->
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>