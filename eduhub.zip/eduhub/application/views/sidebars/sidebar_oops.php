<div id="sidebar_1" class="sidebar one_quarter first">
      <aside>
        <!-- ########################################################################################## -->
        <h2>OOPS Tutorials</h2>
        <nav>
          <ul>
            <li><a href="#">OOPS Home</a></li>
            <li><a href="#">OOPS Introduction</a></li>
            <li><a href="#">OOPS Setup</a>
              <!-- <ul>
                <li><a href="#">Free HTML 5 Templates</a></li>
                <li><a href="#">Free Webdesign Templates</a>
                  <ul>
                    <li><a href="#">Free FireWorks Templates</a></li>
                    <li><a href="#">Free PNG Templates</a></li>
                  </ul>
                </li>
              </ul> -->
            </li>
            <li><a href="#">OOPS Syntax</a></li>
            <li><a href="#">OOPS Variables</a></li>
            <li><a href="#">OOPS Constants</a></li>
            <li><a href="#">OOPS echo/print</a></li>
            <li><a href="#">OOPS Data Types</a></li>
            <li><a href="#">OOPS Loops</a></li>
            <li><a href="#">OOPS Strings</a></li>
            <li><a href="#">OOPS Arrays</a></li>
            <li><a href="#">OOPS Functions</a></li>
            <li><a href="#">OOPS Operators</a></li>
            <li><a href="#">OOPS Cookies</a></li>
            <li><a href="#">OOPS Session</a></li>
            <li><a href="#">OOPS Superglobals</a></li>
          </ul>
        </nav>
        <h2>OOPS Forms</h2>
        <nav>
          <ul>
            <li><a href="#">OOPS Form Handling</a></li>
            <li><a href="#">OOPS Form Validations</a></li>
            <li><a href="#">OOPS Form Complete</a></li>
          </ul>
        </nav>
        <h2>OOPS Advanced</h2>
        <nav>
          <ul>
            <li><a href="#">OOPS Math Function</a></li>
            <li><a href="#">OOPS Date & Time</a></li>
            <li><a href="#">OOPS File Handling</a></li>
            <li><a href="#">OOPS File Uploads</a></li>
            <li><a href="#">OOPS File Jsons</a></li>
          </ul>
        </nav>
        <h2>OOPS OOPS</h2>
        <nav>
          <ul>
            <li><a href="#">OOPS OOPS Intro</a></li>
            <li><a href="#">OOPS Classes & Objects</a></li>
            <li><a href="#">OOPS Constructor</a></li>
            <li><a href="#">OOPS Destructor</a></li>
            <li><a href="#">OOPS Access Modifiers</a></li>
            <li><a href="#">OOPS Inheritance</a></li>
            <li><a href="#">OOPS Constants</a></li>
            <li><a href="#">OOPS Abstract Classes</a></li>
            <li><a href="#">OOPS Traits</a></li>
            <li><a href="#">OOPS Static Classes</a></li>
            <li><a href="#">OOPS Static Methods & Properties</a></li>
          </ul>
        </nav>
        <!-- /nav -->
        <!-- <section>
          <h2>Get In Contact</h2>
          <address>
          Full Name<br>
          Address Line 1<br>
          Address Line 2<br>
          Town/City<br>
          Postcode/Zip<br>
          <br>
          Tel: xxxx xxxx xxxxxx<br>
          Email: <a href="#">contact@domain.com</a>
          </address>
        </section> -->
        <!-- /section -->
        <!-- <section>
          <article>
            <h2>Lorem ipsum dolor</h2>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed.</p>
            <ul class="list indent disc">
              <li><a href="#">Lorem ipsum dolor sit</a></li>
              <li>Etiam vel sapien et</li>
              <li><a href="#">Etiam vel sapien et</a></li>
            </ul>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed. Condimentumsantincidunt dui mattis magna intesque purus orci augue lor nibh.</p>
            <p class="more"><a href="#">Continue Reading &raquo;</a></p>
          </article>
        </section> -->
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>