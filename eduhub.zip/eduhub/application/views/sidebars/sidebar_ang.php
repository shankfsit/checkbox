<div id="sidebar_1" class="sidebar one_quarter first">
      <aside>
        <h2>Angular Tutorials</h2>
        <nav>
          <ul>
            <li><a href="<?php echo base_url()?>angular/">Angular Home</a></li>
            <li><a href="<?php echo base_url()?>angular/environmental_setup">Angular Setup</a>
            </li>
            <li><a href="<?php echo base_url()?>angular/grunt_jasmine">Angular Grunt Jasmine</a></li>
            <li><a href="<?php echo base_url()?>angular/package_json_configuration">Angular Package JSON Config</a></li>
            <li><a href="<?php echo base_url()?>angular/angular_cli">Angular CLI</a></li>
            <li><a href="<?php echo base_url()?>angular/angular_compilation">Angular Compilation</a></li>
          </ul>
        </nav>
        <h2>Components and Templates</h2>
        <nav>
          <ul>
            <li><a href="<?php echo base_url()?>angular/life_cycle_hooks">Angular Life Cycle Hooks</a></li>
            <li><a href="<?php echo base_url()?>angular/component_interaction">Angular Component Interaction</a></li>
            <li><a href="<?php echo base_url()?>angular/directives">Angular Directives</a></li>
            <li><a href="<?php echo base_url()?>angular/pipes">Angular Pipes</a></li>
            <li><a href="<?php echo base_url()?>angular/data_binding">Angular Data Binding</a></li>
            <li><a href="<?php echo base_url()?>angular/reactive_forms">Angular Reactive Forms</a></li>
            <li><a href="<?php echo base_url()?>angular/template_driven_form">Angular Template Driven Forms</a></li>
            <li><a href="<?php echo base_url()?>angular/form_validation">Angular Form Validation</a></li>
            <li><a href="<?php echo base_url()?>angular/template_syntax">Angular Template Syntax</a></li>
            <li><a href="<?php echo base_url()?>angular/navigation_routing">Angular Navigation Routing</a></li>
          </ul>
        </nav>
        <h2>Modules</h2>
        <nav>
          <ul>
            <li><a href="<?php echo base_url()?>angular/">Angular Providers</a></li>
            <li><a href="<?php echo base_url()?>angular/">Angular Singleton services</a></li>
            <li><a href="<?php echo base_url()?>angular/">Angular Lazy Loading</a></li>
            <li><a href="<?php echo base_url()?>angular/">Angular Modules Sharing</a></li>
          </ul>
        </nav>
        <h2>Dependency Injections</h2>
        <nav>
          <ul>
            <li><a href="<?php echo base_url()?>angular/">Angular Dependency Injections</a></li>
            <li><a href="<?php echo base_url()?>angular/">Angular Hierarchical Dependency Injectors</a></li>
            <li><a href="<?php echo base_url()?>angular/">Angular DI Providers</a></li>
          </ul>
        </nav>
        <h2>Angular Advanced</h2>
        <nav>
          <ul>
            <li><a href="<?php echo base_url()?>angular/">Retrieving data using HTTP</a></li>
            <li><a href="<?php echo base_url()?>angular/">HTTP Intercepts</a></li>
            <li><a href="<?php echo base_url()?>angular/">Redux and state management</a></li>
            <li><a href="<?php echo base_url()?>angular/">Rxjs and Observables</a></li>
          </ul>
        </nav>
        <h2>Angular Resources</h2>
        <nav>
          <ul>
            <li><a href="<?php echo base_url()?>angular/interview_questions">Angular Interview Questions</a></li>
            <li><a href="<?php echo base_url()?>angular/">Angular Quick Guide</a></li>
            <li><a href="<?php echo base_url()?>angular/">Angular Quiz</a></li>
            <li><a href="<?php echo base_url()?>angular/">Angular Test</a></li>
          </ul>
        </nav>
        <!-- /nav -->
        <!-- <section>
          <h2>Get In Contact</h2>
          <address>
          Full Name<br>
          Address Line 1<br>
          Address Line 2<br>
          Town/City<br>
          Postcode/Zip<br>
          <br>
          Tel: xxxx xxxx xxxxxx<br>
          Email: <a href="<?php echo base_url()?>angular/">contact@domain.com</a>
          </address>
        </section> -->
        <!-- /section -->
        <!-- <section>
          <article>
            <h2>Lorem ipsum dolor</h2>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed.</p>
            <ul class="list indent disc">
              <li><a href="<?php echo base_url()?>angular/">Lorem ipsum dolor sit</a></li>
              <li>Etiam vel sapien et</li>
              <li><a href="<?php echo base_url()?>angular/">Etiam vel sapien et</a></li>
            </ul>
            <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed. Condimentumsantincidunt dui mattis magna intesque purus orci augue lor nibh.</p>
            <p class="more"><a href="<?php echo base_url()?>angular/">Continue Reading &raquo;</a></p>
          </article>
        </section> -->
        <!-- /section -->
        
      </aside>
    </div>