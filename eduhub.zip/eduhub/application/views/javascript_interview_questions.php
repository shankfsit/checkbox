<!DOCTYPE html>
<html>
<head>
<title>Eduhub - Javascript Interview Questions</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>assets/layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url()?>assets/layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">
<!--[if lt IE 9]>
<link href="../layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="../layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="../layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
</head>
<body class="">
<?php include('header.php');?>
<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
    <?php include('sidebars/sidebar_interview_questions.php');?>
    <!-- ################################################################################################ -->
    <div class="one_half">
      <section class="clear">
        <h1>Javascript Interview Questions</h1>
        <figure class="imgr boxholder"><img style="width: 120px;height: 120px;" src="<?php echo base_url()?>assets/images/demo/php2.jpg" alt=""></figure>
        <p><b>1) What is Javascript ?</b></p>
        <p align="justify">Javascript is a Client Side Scripting Language.</p>
        <hr>
        <a href="#"><img src="<?php echo base_url()?>assets/images/demo/hor_ads1.jpg" alt=""></a>
        <p><b>2) How to check the version of the Codeigniter ?</b></p>
        <p align="justify">Go to system/core/CodeIgniter.php, and then check CI_VERSION constant value define(‘CI_VERSION’, ‘3.1.11’);
        </p>
        <hr>
        <p><b>3) What are the important characters of Codeigniter ?</b></p>
        <p align="justify">Following are the important characters of Codeigniter:
          <ul>
            <li>It is based on MVC Architecture.</li>
            <li>Simple and Strong documentation.</li>
            <li>Simple Solutions over complexity.</li>
            <li>Strong Security.</li>
            <li>Almost Zero Configurations.</li>
          </ul>
        </p>
        <hr>
        <p><b>4) What is helpers in Codeigniter and how to load a helper ?</b></p>
        <p align="justify">Codeigniter helpers are used to perform a specific task, which is nothing but a collection of functions in a particular category. Codeigniter have many helpers where each helper performs a specific task with no dependencies on other functions.<br><br>
          By default the helpers are not loaded, So once the helpers are loaded it becomes globally available to that controller and view.<br><br>
          Helpers are stored in system/helpers, and application/helpers.<br><br>
          Loading a helper is very simple :<br><br>
          $this->load->helper('cart');
        </p>
        <hr>
        <p><b>5) What is libraries and how to load a library ?</b></p>
        <p align="justify">Libraries are very important part of Codeigniter as it increases the speed of developing an application. Codeigniter provides a rich set of libraries. Libraries are nothing but a class which consists of functions that simplify the developing work. Codeigniter provides many in built libraries such as Calendaring Class, Shopping Cart Class, Email Class and more.<br><br>
          All inbiult libraries are exists in system/libraries.<br><br>
          Loading a library is very simple :<br><br>
          $this->load->library('email');
        </p>
        <hr>
        <p><b>6) Explain routing in Codeigniter ?</b></p>
        <p align="justify">
        </p>
        <hr>
        <p><b>7) What are hooks in Codeigniter and what are the hook point in Codeigniter ?</b></p>
        <p align="justify">
        </p>
        <hr>
        <p><b>8) List some pre-defined functions in Codeigniter ?</b></p>
        <p align="justify">
        </p>
        <hr>
        <p><b>9) How to remove index.php from the URL in Codeigniter ?</b></p>
        <p align="justify"> 
        </p>
        <hr>
        <p><b>10) What is model and how to load it ?</b></p>
        <p align="justify">
        </p>
        <hr>
        
        
      </section>
      <section>
        <h1>Other Interview Questions</h1>
        <table>
          <tbody>
            <tr class="light">
              <td><a style="color: black;" href="<?php echo base_url()?>javascript/interview_questions">Javascript Interview Questions</a></td>
              <td><a style="color: black;" href="<?php echo base_url()?>jquery/interview_questions">Jquery Interview Questions</a></td>
              
            </tr>
            <tr class="dark">
              <td><a style="color: black;" href="<?php echo base_url()?>mysql/interview_questions">Mysql Interview Questions</a></td>
              <td><a style="color: black;" href="<?php echo base_url()?>oops/interview_questions">OOPS Interview Questions</a></td>
            </tr>
          </tbody>
        </table>
      </section>
    </div>
    <!-- ################################################################################################ -->
    <div id="sidebar_2" class="sidebar one_quarter">
      <aside class="clear">
        <!-- ########################################################################################## -->
        
        <section class="clear">
          <ul class="nospace">
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/vertical_ads1.jpg" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/vertical_ads2.gif" alt=""></a></li>
          </ul>
        </section>
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<!-- Footer -->
<?php include('footer.php')?>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>window.jQuery || document.write('<script src="../layout/scripts/jquery-latest.min.js"><\/script>\
<script src="../layout/scripts/jquery-ui.min.js"><\/script>')</script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); });</script>
<script src="../layout/scripts/jquery-mobilemenu.min.js"></script>
<script src="../layout/scripts/custom.js"></script>
</body>
</html>