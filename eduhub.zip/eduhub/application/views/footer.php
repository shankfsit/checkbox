<div class="wrapper row2">
  <div id="footer" class="clear">
    <div class="one_quarter first">
      <h2 class="footer_title">IT Technologies</h2>
      <nav class="footer_nav">
        <ul class="nospace">
          <li><a href="#">Home</a></li>
          <li><a href="#">Html</a></li>
          <li><a href="#">PHP</a></li>
          <li><a href="#">Javascript</a></li>
          <li><a href="#">Jquery</a></li>
          <li><a href="#">OOPS Concepts</a></li>
          <li><a href="#">Angular</a></li>
          <li><a href="#">Others</a></li>
        </ul>
      </nav>
    </div>
    <div class="one_quarter">
      <h2 class="footer_title">Other Tutorials</h2>
      <nav class="footer_nav">
        <ul class="nospace">
          <li><a href="#">Interview Preparation</a></li>
          <li><a href="#">Mock Interviews</a></li>
          <li><a href="#">Banks Preparation</a></li>
          <li><a href="#">UPSC Preparation</a></li>
          <li><a href="#">Gate Tutorials</a></li>
          <li><a href="#">Railways Tutorials</a></li>
          <li><a href="#">NET Tutorials</a></li>
        </ul>
      </nav>
    </div>
    <div class="one_quarter">
      <h2 class="footer_title">Study Materials</h2>
      <nav class="footer_nav">
        <ul class="nospace">
          <li><a href="#">Banks Preparation Materials</a></li>
          <li><a href="#">UPSC Preparation Materials</a></li>
          <li><a href="#">Gate Tutorials Materials</a></li>
          <li><a href="#">Railways Tutorials Materials</a></li>
          <li><a href="#">NET Tutorials Materials</a></li>
        </ul>
      </nav>
    </div>
    <div class="one_quarter">
      <h2 class="footer_title">Contact Us</h2>
      <form class="rnd5" action="#" method="post">
        <div class="form-input clear">
          <label for="ft_author">Name <span class="required">*</span><br>
            <input type="text" name="ft_author" id="ft_author" value="" size="22">
          </label>
          <label for="ft_email">Email <span class="required">*</span><br>
            <input type="text" name="ft_email" id="ft_email" value="" size="22">
          </label>
        </div>
        <div class="form-message">
          <textarea name="ft_message" id="ft_message" cols="25" rows="10"></textarea>
        </div>
        <p>
          <input type="submit" value="Submit" class="button small orange">
          &nbsp;
          <input type="reset" value="Reset" class="button small grey">
        </p>
      </form>
    </div>
  </div>
</div>
<div class="wrapper row4">
  <div id="copyright" class="clear">
    <p class="fl_left" style="color: white;">Copyright &copy; 2018 - All Rights Reserved - <a href="#"  style="color: white;">Eduhub</a></p>
    <p class="fl_right"  style="color: white;">Developed by <a target="_blank" href="http://cart19.000webhostapp.com/eduhub/" title="Eduhub"  style="color: white;">Eduhub</a></p>
  </div>
</div>