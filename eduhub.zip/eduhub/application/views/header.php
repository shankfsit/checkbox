<div class="wrapper row1">
  <header id="header" class="full_width clear">
    <div id="hgroup">
      <p style="font-family: Comic Sans MS"><b><a href="<?php echo base_url()?>">TUTORS<span style="color: green;">BOARD</span></a></b></p>
      <!-- <h2>Go Ahead....</h2> -->
    </div>
    <div id="header-contact">
      <ul class="list none">
        <li><span class="icon-envelope"></span> <a href="#">info@tutorsboard.com</a></li>
        <li><span class="icon-phone"></span> +xx xxx xxxxxxxxxx</li>
      </ul>
    </div>
  </header>
</div>
<!-- ################################################################################################ -->
<div class="wrapper row2">
  <nav id="topnav">
    <ul class="clear">
      <li class="active"><a href="<?php echo base_url()?>" title="Homepage">HOME</a></li>
      <li><a href="<?php echo base_url()?>html" title="Homepage">HTML</a></li>
      <li><a href="<?php echo base_url()?>php" title="Pages">PHP</a>
        <!-- <ul>
          <li><a href="pages/full-width-content.html" title="Full Width Content">Full Width Content</a></li>
          <li><a href="pages/content-leftsidebar.html" title="Content + Left Sidebar">Content + Left Sidebar</a></li>
          <li><a href="pages/content-rightsidebar.html" title="Content + Right Sidebar">Content + Right Sidebar</a></li>
          <li><a href="pages/content-bothsidebars.html" title="Content + Both Sidebars">Content + Both Sidebars</a></li>
          <li><a href="pages/contact.html" title="Contact">Contact</a></li>
          <li><a href="pages/404.html" title="404">404</a></li>
          <li><a href="pages/testimonials.html" title="Testimonials">Testimonials</a></li>
          <li><a href="pages/about-us.html" title="About Us">About Us</a></li>
          <li><a href="pages/team-member.html" title="Team Member">Team Member</a></li>
          <li class="last-child"><a href="pages/faq.html" title="FAQ">FAQ</a></li>
        </ul> -->
      </li>
      <li><a href="<?php echo base_url()?>javascript" title="Elements">JAVASCRIPT</a>
        <!-- <ul>
          <li><a href="elements/buttons.html" title="Buttons">Buttons</a></li>
          <li><a href="elements/alert-messages.html" title="Alert Messages">Alert Messages</a></li>
          <li><a href="elements/font-icons.html" title="Font Icons">Font Icons</a></li>
          <li><a href="elements/call-to-action.html" title="Call To Action">Call To Action</a></li>
          <li><a href="elements/columns.html" title="Columns">Columns</a></li>
          <li><a href="elements/columns-no-gutter.html" title="Columns - No Gutter">Columns - No Gutter</a></li>
          <li><a href="elements/lists.html" title="Lists">Lists</a></li>
          <li><a href="elements/accordions.html" title="Accordions">Accordions</a></li>
          <li><a href="elements/tabs.html" title="Tabs">Tabs</a></li>
          <li><a href="elements/toggles.html" title="Toggles">Toggles</a></li>
          <li class="last-child"><a href="elements/pricing-tables.html" title="Pricing Tables">Pricing Tables</a></li>
        </ul> -->
      </li>
      <li><a href="<?php echo base_url()?>jquery" title="Portfolio Layouts">JQUERY</a>
        <!-- <ul>
          <li><a href="portfolio-layouts/portfolio-overview-full-width-content.html" title="Full Width Portfolio">Full Width Portfolio</a></li>
          <li><a href="portfolio-layouts/portfolio-overview-2columns.html" title="2 Column Grid">2 Column Grid</a></li>
          <li><a href="portfolio-layouts/portfolio-overview-2columns-leftsidebar.html" title="2 Column Grid + Left Sidebar">2 Col. Grid + Left Sidebar</a></li>
          <li><a href="portfolio-layouts/portfolio-overview-2columns-rightsidebar.html" title="2 Column Grid + Right Sidebar">2 Col. Grid + Right Sidebar</a></li>
          <li><a href="portfolio-layouts/portfolio-overview-2columns-bothsidebars.html" title="2 Column Grid + Both Sidebars">2 Col. Grid + Both Sidebars</a></li>
          <li><a href="portfolio-layouts/portfolio-overview-3columns.html" title="3 Column Grid">3 Column Grid</a></li>
          <li><a href="portfolio-layouts/portfolio-overview-3columns-leftsidebar.html" title="3 Column Grid + Left Sidebar">3 Col. Grid + Left Sidebar</a></li>
          <li><a href="portfolio-layouts/portfolio-overview-3columns-rightsidebar.html" title="3 Column Grid + Right Sidebar">3 Col. Grid + Right Sidebar</a></li>
          <li><a href="portfolio-layouts/portfolio-overview-3columns-bothsidebars.html" title="3 Column Grid + Both Sidebars">3 Col. Grid + Both Sidebars</a></li>
          <li class="last-child"><a href="portfolio-layouts/portfolio-overview-4columns.html" title="4 Column Grid">4 Column Grid</a></li>
        </ul> -->
      </li>
      <li><a href="<?php echo base_url()?>mysql" title="Gallery Layouts">MYSQL</a>
        <!-- <ul>
          <li><a href="gallery-layouts/gallery-full-width-content.html" title="Full Width Gallery">Full Width Gallery</a></li>
          <li><a href="gallery-layouts/gallery-2columns.html" title="2 Column Grid">2 Column Grid</a></li>
          <li><a href="gallery-layouts/gallery-2columns-leftsidebar.html" title="2 Column Grid + Left Sidebar">2 Col. Grid + Left Sidebar</a></li>
          <li><a href="gallery-layouts/gallery-2columns-rightsidebar.html" title="2 Column Grid + Right Sidebar">2 Col. Grid + Right Sidebar</a></li>
          <li><a href="gallery-layouts/gallery-2columns-bothsidebars.html" title="2 Column Grid + Both Sidebars">2 Col. Grid + Both Sidebars</a></li>
          <li><a href="gallery-layouts/gallery-3columns.html" title="3 Column Grid">3 Column Grid</a></li>
          <li><a href="gallery-layouts/gallery-3columns-leftsidebar.html" title="3 Column Grid + Left Sidebar">3 Col. Grid + Left Sidebar</a></li>
          <li><a href="gallery-layouts/gallery-3columns-rightsidebar.html" title="3 Column Grid + Right Sidebar">3 Col. Grid + Right Sidebar</a></li>
          <li><a href="gallery-layouts/gallery-3columns-bothsidebars.html" title="3 Column Grid + Both Sidebars">3 Col. Grid + Both Sidebars</a></li>
          <li><a href="gallery-layouts/gallery-4columns.html" title="4 Column Grid">4 Column Grid</a></li>
          <li class="last-child"><a href="gallery-layouts/gallery-5columns.html" title="5 Column Grid">5 Column Grid</a></li>
        </ul> -->
      </li>
      <li><a href="<?php echo base_url()?>oops" title="Link Text">OOPS</a></li>
      <li><a href="<?php echo base_url()?>angular" title="Link Text">ANGULAR</a></li>
      <!-- <li class="last-child"><a href="#" title="A Very Long Link Text">A Very Long Link Text</a></li> -->
      <li><a class="drop" href="#" title="Gallery Layouts">Interview Questions</a>
        <ul>
          <li><a href="<?php echo base_url()?>php/interview_questions" title="Full Width Gallery">PHP Interview Questions</a></li>
          <li><a href="<?php echo base_url()?>javascript/interview_questions" title="Full Width Gallery">Javascript Interview Questions</a></li>
          <li><a href="<?php echo base_url()?>jquery/interview_questions" title="Full Width Gallery">Jquery Interview Questions</a></li>
          <li><a href="<?php echo base_url()?>mysql/interview_questions" title="Full Width Gallery">Mysql Interview Questions</a></li>
          <li><a href="<?php echo base_url()?>oops/interview_questions" title="Full Width Gallery">OOPS Interview Questions</a></li>
          <li><a href="<?php echo base_url()?>angular/interview_questions" title="Full Width Gallery">Angular Interview Questions</a></li>
          <li><a href="<?php echo base_url()?>codeigniter/interview_questions" title="Full Width Gallery">Codeigniter Interview Questions</a></li>
        </ul>
      </li>
      <li><a class="drop" href="#" title="Gallery Layouts">OTHERS..</a>
        <ul>
          <li><a href="#" title="Full Width Gallery">Gate Preparation</a></li>
          <li><a href="#" title="Full Width Gallery">Vocabs Preparation</a></li>
          <li><a href="#" title="Full Width Gallery">Communication Skills</a></li>
          <li><a href="#" title="Full Width Gallery">Food Recipe Preparation</a></li>
          <li><a href="#" title="Full Width Gallery">Rangoli Preparation</a></li>
          <li><a href="#" title="Full Width Gallery">Sanskrit Tutorials</a></li>
          <li><a href="#" title="Full Width Gallery">Affiliate Marketing</a></li>
          <li><a href="#" title="Full Width Gallery">Digital Marketing</a></li>
          <li><a href="#" title="Full Width Gallery">Python Tutorials</a></li>
          <li><a href="<?php echo base_url()?>codeigniter" title="Full Width Gallery">Codeigniter Tutorials</a></li>
          <li><a href="#" title="Full Width Gallery">Laravel Tutorials</a></li>
        </ul>
      </li>
    </ul>
  </nav>
</div>