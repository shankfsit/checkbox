<!DOCTYPE html>
<html>
<head>
<title>Eduhub - HTML</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>assets/layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url()?>assets/layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">
<!--[if lt IE 9]>
<link href="../layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="../layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="../layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
</head>
<body class="">
<?php include('header.php');?>
<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
    <?php include('sidebars/sidebar_html.php');?>
    <!-- ################################################################################################ -->
    <div class="one_half">
      <section class="clear">
        <h1>HTML Tutorial</h1>
        <figure class="imgr boxholder"><img style="width: 120px;height: 120px;" src="<?php echo base_url()?>assets/images/demo/html2.png" alt=""></figure>
        <p>HTML Stands for Hypertext Markup Language which is used for creating Web Pages. HTML can embed programs written in scriting languages such as Javascript , PHP etc..</p>
        <p>HTML elements are the building blocks of HTML pages. With HTML constructs, images and other objects such as interactive forms may be embedded into the rendered page.</p>
      </section>
      <div class="divider2"></div>
      <section>
        <h2>Lets Start With an Example</h2>

        <div class="calltoaction opt1">
          <div class="push20">
            <xmp style="text-transform: lowercase;margin-left: -125px;margin-top: -40px;">
              <!DOCTYPE html>
              <html>
              <head>
                <title>This is My Fisrt HTML Exercise</title>
              </head>
              <body>
                <h2>Hello World</h2>
                <p>Welcome to Eduhub..</p>
              </body>
              </html>
            </xmp>
              
          </div>
          <!-- <div><a href="#" class="button large gradient orange">Apply Today</a></div> -->
        </div>
        <p>OUTPUT</p>
        <div class="calltoaction opt1">
          <div class="push20">
            
              
                <h2>Hello World</h2>
                <p>Welcome to Eduhub..</p>
             
            
              
          </div>
          <!-- <div><a href="#" class="button large gradient orange">Apply Today</a></div> -->
        </div>
        <br>
        <div><a target="_blank" href="<?php echo base_url()?>html/tryit_html_home" class="button small gradient orange">Try it Online</a></div>
      </section>
      <!-- <section>
        <h1>Table(s)</h1>
        <table>
          <thead>
            <tr>
              <th>Header 1</th>
              <th>Header 2</th>
              <th>Header 3</th>
              <th>Header 4</th>
            </tr>
          </thead>
          <tbody>
            <tr class="light">
              <td>Value 1</td>
              <td>Value 2</td>
              <td>Value 3</td>
              <td>Value 4</td>
            </tr>
            <tr class="dark">
              <td>Value 5</td>
              <td>Value 6</td>
              <td>Value 7</td>
              <td>Value 8</td>
            </tr>
            <tr class="light">
              <td>Value 9</td>
              <td>Value 10</td>
              <td>Value 11</td>
              <td>Value 12</td>
            </tr>
            <tr class="dark">
              <td>Value 13</td>
              <td>Value 14</td>
              <td>Value 15</td>
              <td>Value 16</td>
            </tr>
          </tbody>
        </table>
      </section> -->
      <!-- <div id="respond">
        <h2>Contact Us</h2>
        <form class="rnd5" action="#" method="post">
          <div class="form-input clear">
            <label class="one_third first" for="author">Name <span class="required">*</span><br>
              <input type="text" name="author" id="author" value="" size="22">
            </label>
            <label class="one_third" for="email">Email <span class="required">*</span><br>
              <input type="text" name="email" id="email" value="" size="22">
            </label>
            <label class="one_third" for="subject">Subject<br>
              <input type="text" name="subject" id="subject" value="" size="22">
            </label>
          </div>
          <div class="form-message">
            <textarea name="message" id="message" cols="25" rows="10"></textarea>
          </div>
          <p>
            <input type="submit" value="Submit">
            &nbsp;
            <input type="reset" value="Reset">
          </p>
        </form>
      </div> -->
    </div>
    <!-- ################################################################################################ -->
    <div id="sidebar_2" class="sidebar one_quarter">
      <aside class="clear">
        <!-- ########################################################################################## -->
        <!-- <h2>Aliquatjusto Nam</h2> -->
        <section class="clear">
          <ul class="nospace">
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
            <li><a href="#"><img src="<?php echo base_url()?>assets/images/demo/sidebar-banner.gif" alt=""></a></li>
          </ul>
        </section>
        <!-- /section -->
        <!-- ########################################################################################## -->
      </aside>
    </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<!-- Footer -->
<?php include('footer.php')?>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>window.jQuery || document.write('<script src="../layout/scripts/jquery-latest.min.js"><\/script>\
<script src="../layout/scripts/jquery-ui.min.js"><\/script>')</script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); });</script>
<script src="../layout/scripts/jquery-mobilemenu.min.js"></script>
<script src="../layout/scripts/custom.js"></script>
</body>
</html>